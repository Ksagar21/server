const mongoose = require('mongoose');

const serviceProviderSchema = new mongoose.Schema({
    shopName:{type: String, required: true},
    name:{type:String},
    description:{type:String},
    category:{type:String},
    phoneNo:{type:Number},
    emailId: { type: String},
    shopEmail:{type:String,required:true,unique:true},
    address:{type:String},
     stars:{type:Number},
    state:{type:String},
    city:{type:String},
    area:{type:String},
    postalCode:{type:String},
    isverified:{type:Boolean},
});

const Providers = mongoose.model('ServiceProviders', serviceProviderSchema);
module.exports = Providers;